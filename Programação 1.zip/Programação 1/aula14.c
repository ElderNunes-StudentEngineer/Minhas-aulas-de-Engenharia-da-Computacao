#include<stdio.h>
#include<stdlib.h>

float calculaImc(float peso, float altura){
    float imc;
    imc = peso / (altura*altura);
    printf("Seu imc é %.2f!\n", imc);
    return imc;
}

int main(){
    float MeuPeso = 65;
    float MinhaAltura = 1.72;
    float MeuImc;

    MeuImc = calculaImc(MeuPeso, MinhaAltura);

    printf("Seu imc é %.2f!\n", MeuImc);
    return 0;
}