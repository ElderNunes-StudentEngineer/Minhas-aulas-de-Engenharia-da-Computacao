#include<stdio.h>
#include<stdlib.h>

int main(){

    int numero1, numero2, numero3, angulo;

    printf("Digite o primeiro número: \n");
    scanf("%d", &numero1);
    printf("Digite o segundo número: \n");
    scanf("%d", &numero2);
    printf("Digite o terceiro número: \n");
    scanf("%d", &numero3);
    printf("Digite um Ângulo: \n");
    scanf("%d", &angulo);

    if(numero1 == numero2 && numero1 == numero3 && numero2 == numero3){
        printf("O Triângulo é equilátero.\n");

    }else if(angulo == 90){
        printf("O Triângulo é retângulo.\n");

    }else if(numero1 != numero2 && numero1 != numero3 && numero2 != numero3){
        printf("O Triângulo é escaleno.\n");

    }else if(numero1 == numero2 && numero1 != numero3 && numero2 != numero3){
        printf("O Triângulo é isósceles.\n");

    }else if(numero1 != numero2 && numero1 != numero3 && numero2 == numero3){
        printf("O Triângulo é isósceles.\n");
    }




    return 0;
}