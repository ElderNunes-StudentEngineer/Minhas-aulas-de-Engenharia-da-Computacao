#include<stdio.h>
#include<stdlib.h>

/*
5) Faça um programa que some as matrizes A e B,
gerando C
*/

int main(){

    int l, c;
    int matrizA[3][3];
    int matrizB[3][3];
    int matrizC[3][3];

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("Digite a matriz A [%i][%i]: ", l, c);
            scanf("%d", &matrizA[l][c]);
        }
    }

        for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("Digite a matriz B [%i][%i]: ", l, c);
            scanf("%d", &matrizB[l][c]);
        }
    }

        for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            matrizC[l][c] = matrizA[l][c] + matrizB[l][c];
        }
    }

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("O valor da matriz C [%i][%i]: %d\n",l,c,matrizC[l][c]);
        }
    }


    return 0;
}