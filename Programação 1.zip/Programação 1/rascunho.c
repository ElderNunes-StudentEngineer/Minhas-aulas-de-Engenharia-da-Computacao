#include<stdio.h>
#include<stdlib.h>

int main(){

    int i = 0;
    while(i >= 0 && i <= 100){
        printf("O valor de i: %d\n", i);
        i++;
    }




    return 0;
}