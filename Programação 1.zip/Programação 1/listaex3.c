#include<stdio.h>
#include<stdlib.h>

int main(){

    int horas, seg, min;
    int segfaltam;
    int hora1seg;
    int min1seg;
    int diaseg = 86.400;

    printf("Digite o número de horas atuais: \n");
    scanf("%d", &horas);
    printf("Digite o número de minutos atuais: \n");
    scanf("%d", &min);
    printf("Digite o número de segundos atuais: \n");
    scanf("%d", &seg);

    printf("Agora são: %d:%d:%d \n", horas, min, seg);

    hora1seg = horas * 3600;
    min1seg = min * 60;

    segfaltam = (hora1seg + min1seg + seg) - diaseg;

    printf("Faltam %d segundos para terminar o dia \n", segfaltam);



}