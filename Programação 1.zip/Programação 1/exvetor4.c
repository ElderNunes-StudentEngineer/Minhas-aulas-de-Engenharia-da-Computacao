#include<stdio.h>
#include<stdlib.h>

/*
Crie e inicialize um vetor de inteiros de tamanho 8. Faça a soma dos seus elementos, e apresente o resultado.
*/

int main(){

int vetor[8];
int vetorsoma = 0;
int i;

for(i=0; i<8; i++){
    printf("Digite o valor %d do vetor: ", i);
    scanf("%d", &vetor[i]);
}

for(i=0; i<8; i++){
    vetorsoma += vetor[i];
}

printf("A soma dos elementos é: %d\n", vetorsoma);

    return 0;
}