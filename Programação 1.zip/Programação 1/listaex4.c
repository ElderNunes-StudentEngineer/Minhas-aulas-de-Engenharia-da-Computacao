#include<stdio.h>
#include<stdlib.h>

int main(){

    int idade1, idade2, idade3, media;

    printf("Digite a idade da primeira pessoa: ");
    scanf("%d", &idade1);
    printf("Digite a idade da segunda pessoa: ");
    scanf("%d", &idade2);
    printf("Digite a idade terceira pessoa: ");
    scanf("%d", &idade3);

    if(idade1 > idade2 && idade1 > idade3){

        printf("A primeira pessoa é a mais velha!\n");


    }else if(idade2 > idade1 && idade2 > idade3){

        printf("A segunda pessoa é a mais velha1\n");

    }else if(idade3 > idade1 && idade3 > idade2){

        printf("A terceira pessoa é a mais velha!\n");
    }else{

        printf("As idades não são distintas!\n");
    }
    
    media = (idade1 + idade2 + idade3)/3;

    printf("A média das idades é: %d \n", media);


}