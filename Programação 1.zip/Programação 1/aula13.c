#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

/*
    char nome[21];

    printf("Digite seu nome: ");
    //scanf("%20[^\n]", &nome);

    //fgets(nome, 20, stdin);
    //nome[strcspn(nome, "\n")] = '\0';
    //setbuf(stdin, NULL);

    printf("Olá %s! Agora você sabe string!\n", nome);

----------------------------------------------------------------------------------

    char nomes[5][21];

    for(int l=0; l<5; l++){
        setbuf(stdin, NULL);
        printf("Digite o nome: ");
        scanf("%20[^\n]", nomes[l]);
    }

    for(int l=0; l<5; l++){
        printf("%s faz parte da UTFPR!\n", nomes[l]);
        //%-20s para alinhar a esquerda
        //%20s para alinhar a direita
    }
------------------------------------------------------------------------------------

    char nome[21];
    int tamanho;

    printf("Digite o nome: ");
    scanf("%20[^\n]", &nome);

    tamanho = strlen(nome);

    printf("Nome: %s\n", nome);
    printf("Foram digitados %d caracteres\n", tamanho);

--------------------------------------------------------------------------------------

    char nome[21];
    char novonome[21];

    printf("Digite o nome: ");
    scanf("%20[^\n]", &nome);

    strcpy(novonome, nome);

    printf("Novo nome: %s\n", novonome);
-------------------------------------------------------------------------------------

    char nome[21];
    char sobrenome[21] = " Nunes";

    printf("Digite o nome: ");
    scanf("%20[^\n]", &nome);

    strcat(nome, sobrenome);
    //strcat(nome, " Nunes");

    printf("Nome Completo: %s\n", nome);
-------------------------------------------------------------------------------------

    char senhaCorreta[41] = "Helloworld123";
    char senhaDigitada[41];

    printf("Digite o nome: ");
    scanf("%40[^\n]", &senhaDigitada);

    if(strcmp(senhaCorreta, senhaDigitada) == 0){
        printf("Acesso Liberado!\n");
    }else{
        printf("Senha Incorreta. A PF será comunicada!\n");
    }

*/


    return 0;
}