#include<stdio.h>
#include<stdlib.h>

int main(){

    float nota;

    do{
    printf("Digite sua nota: \n");
    scanf("%f", &nota);

    }while(nota > 10 || nota < 0);
   
    printf("Nota aceita: %.2f\n", nota);


    return 0;
}