#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
2) Faça um programa que armazene o nome e salário de 5
empregados. Em seguida calcule um aumento de 8% nos
salários e exiba a nova folha de pagamentos
*/

int main(){

    char nome[5][21];
    double salario[5];

    for(int n=0; n<5; n++){
            setbuf(stdin, NULL);
            printf("Digite o nome: ");
            scanf("%20[^\n]", &nome[n]);

            printf("Digite o salário: ");
            scanf("%lf", &salario[n]);

            salario[n] *= 1.08;

    }

    for(int n=0; n<5; n++){
        printf("A nova folha de pagamento de %s é de %.2lf reais.\n", nome[n], salario[n]);

    }





    return 0;
}