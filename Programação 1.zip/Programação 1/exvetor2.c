#include<stdio.h>
#include<stdlib.h>
#include<math.h>

/*
2) Crie um algoritmo que receba 10 números e os armazene em
um vetor A. Em seguida, gere o vetor B onde cada elemento é o
quadrado do valor da mesma posição no vetor A 

Sempre que usar o math.h: 
1- gcc exvetor2.c -o main -lm
2- ./main
*/

int main(){

int vetorA[10];
int vetorB[10];
int i;

for(i=0; i<10; i++){
    printf("Digite o valor %d no Vetor A: ", i);
    scanf("%d", &vetorA[i]);
}

for(i=0; i<10; i++){
    vetorB[i] = pow(vetorA[i], 2);
}

    printf("O quadado é: \n");
    for(i=0; i<10; i++){
        printf("%d ", vetorB[i]);
    }
    
    printf("\n ");

    return 0;
}