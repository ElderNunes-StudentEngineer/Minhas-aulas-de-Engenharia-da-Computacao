#include<stdio.h>
#include<stdlib.h>
/*
3) Faça um programa que solicite o tamanho de um quadrado e mostre a borda de um quadrado utilizando o caracter #.
Exemplo:
Digite o tamanho desejado: 10

#	#	#	#	#	#	#	#	#	#
#									#
#									#
#									#
#									#
#									#
#									#
#									#
#									#
#	#	#	#	#	#	#	#	#	#
*/
int main(){
    int tamanho;

    printf("Digite o tamanho do quadrado: ");
    scanf("%d", &tamanho);
/*
    for (int l = 0; l < tamanho; l++){
        for (int c = 0; c < tamanho; c++){
        printf("# ");
        }
        printf("\n");
    }
*/

    for (int l = 0; l < tamanho; l++){
        for (int c = 0; c < tamanho; c++){
        if(l == 0 || l == tamanho-1 || c == 0 || c == tamanho-1 || c == l || l + c == tamanho-1){
            printf("# ");
        }else{
            printf("  ");
        }
            
        }
            printf("\n");
    }

    return 0;
}