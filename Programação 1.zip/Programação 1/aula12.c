#include<stdio.h>
#include<stdlib.h>

int main(){

    int l, c;
    int matriz[3][4];
    int contador = 0;

    for(l=0; l<3; l++){
        for(c=0; c<4; c++){
            matriz[l][c] = contador++;
            //printf("Digite a matriz[%i][%i]: ", l, c);
            //scanf("%d", &matriz[l][c]);
        }
    }

    for(l=0; l<3; l++){
        for(c=0; c<4; c++){
            printf("%3d ", matriz[l][c]);
        }
        printf("\n");// entre o for
    }








    return 0;
}