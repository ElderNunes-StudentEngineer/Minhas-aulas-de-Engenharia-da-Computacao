#include<stdio.h>
#include<stdlib.h>

int main(){

    int dezena, unidade;

    printf("Digite a dezena e a unidade: \n");
    scanf("%d", &dezena);

    switch (dezena){
        case 10 :
            printf("Dez");
            break;
        case 20 :
            printf("Vinte e ");
            break;
        case 30 :
            printf("Trinta e ");
            break;
        case 40 :
            printf("Quarenta e ");
            break;
        case 50 :
            printf("Cinquenta e ");
            break;
        case 60 : 
            printf("Sessenta e ");
            break;
        case 70 :
            printf("Setenta e ");
            break;
        case 80 : 
            printf("Oitenta e ");
            break;
        case 90 :
            printf("Noventa e ");
            break;
        default :
            printf("Inválido!\n");

    }
    scanf("%d", &unidade);

    switch(unidade){
        case 1 :
            printf("um\n");
            break;
        case 2 :
            printf("dois\n");
            break; 
        case 3 : 
            printf("três\n");
            break;
        case 4 : 
            printf("quatro\n");
            break;
        case 5 :
            printf("cinco\n");
            break;
        case 6 :
            printf("seis\n");
            break;
        case 7 :
            printf("sete\n");
            break;
        case 8 :
            printf("oito\n");
            break;
        case 9 :
            printf("nove\n");
            break;
        default :
            printf("Inválido!\n");
    }

    printf("Valor por extenso: %d%d\n", dezena, unidade);


    return 0;
}
