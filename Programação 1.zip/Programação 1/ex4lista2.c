#include<stdio.h>
#include<stdlib.h>
/*
4) Faça um programa que leia e armazene um vetor (VetorA) de inteiros e tamanho 10. Crie um VetorB, de mesmo tamanho, gerado a partir do Vetor A invertido (de trás para frente). Em seguida, calcule o VetorC que deverá ser o resultado do VetorA multiplicado pelo escalar 3 e em seguida subtraído do Vetor B.
*/
int main(){

    int VetorA[10];
    int VetorB[10];
    int VetorC[10];

    for(int i=0; i<10; i++){
        printf("Digite o vetorA:");
        scanf("%d",&VetorA[i]);
    }

    printf("\n");

    for(int i,j=9; i,j>=0; i++,j--){
        VetorB[i] = VetorA[j];
        printf("O vetorB: %d\n", VetorB[i]);

    }

    printf("\n");

    for(int k=0; k<10; k++){
        VetorC[k] = (VetorA[k] * 3) - 8;
        printf("O vetorC: %d\n", VetorC[k]);
    }




    return 0;
}