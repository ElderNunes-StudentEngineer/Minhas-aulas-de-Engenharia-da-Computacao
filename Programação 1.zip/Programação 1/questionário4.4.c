#include<stdio.h>
#include<stdlib.h>

int main() {

    float altura = 1.70;
    float pesoideal = 72.7 * altura - 58;

    printf("Seu peso ideal é: %.2f\n", pesoideal);
}