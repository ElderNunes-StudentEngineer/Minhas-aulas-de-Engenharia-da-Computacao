#include<stdio.h>
#include<stdlib.h>

int main(){

    int i;
    int contapositivos = 0;
    int contapares = 0;
    int somapositivos = 0;

    printf("Digite um número: ");
    scanf("%d", &i);
    
    while(i > 0){

        contapositivos++;
        //somapositivos = somapositivos + i;
        somapositivos += i;

        if(i % 2 == 0){

            contapares++;

        }
        
        printf("Valor de i: %i\n", i);
        printf("Digite um número: ");
        scanf("%d", &i);
        
    }

    printf("Foram digitados %d números positivos\n", contapositivos);
    printf("Foram digitados %d números pares\n", contapares);
    printf("A soma dos positivos é: %d\n", somapositivos);

    return 0;
}