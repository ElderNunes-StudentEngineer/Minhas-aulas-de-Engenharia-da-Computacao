#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(){

    float x1, y1, x2, y2;
    float distancia;

    printf("Digite a coordenada X1: ");
    scanf("%f", &x1);
    printf("Digite a coordenada Y1: ");
    scanf("%f", &y1);
    printf("Digite a coordenada X2: ");
    scanf("%f", &x2);
    printf("Digite a coordenada Y2: ");
    scanf("%f", &y2);

    distancia = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));

    printf("A distância dos dois pontos é: %.2f\n ", distancia);




}


    



