#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

    char frase[101];
    int contaA = 0;
    int contaE = 0;
    int contaI = 0;
    int contaO = 0;
    int contaU = 0;
    int tamanho;
    
    printf("Digite uma frase: ");
    fgets(frase, 101, stdin);
    frase[strcspn(frase, "/n")] = '\0';
    tamanho = strlen(frase);

    for(int i=0; i< tamanho; i++){
        if(frase[i] == 'a' || frase[i] == 'A'){
            contaA++;
        }else if(frase[i] == 'e' || frase[i] == 'E'){
            contaE++;
        }else if(frase[i] == 'i' || frase[i] == 'I'){
            contaI++;
        }else if(frase[i] == 'o' || frase[i] == 'O'){
            contaO++;
        }else if(frase[i] == 'u' || frase[i] == 'U'){
            contaU++;
        }        
    }

    printf("Existem %d letras A\n", contaA);
    printf("Existem %d letras E\n", contaE);
    printf("Existem %d letras I\n", contaI);
    printf("Existem %d letras O\n", contaO);
    printf("Existem %d letras U\n", contaU);






    return 0;
}