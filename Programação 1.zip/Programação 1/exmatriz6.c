#include<stdio.h>
#include<stdlib.h>

/*
6)Faça um programa que multiplique as matrizes A e D
abaixo gerando matriz AD
*/

int main(){

    int l, c, v;
    int matrizA[2][3];
    int matrizD[3][2];
    int matrizAD[2][2];

    for(l=0; l<2; l++){
        for(c=0; c<3; c++){
            printf("Digite a matriz A [%i][%i]: ", l, c);
            scanf("%d", &matrizA[l][c]);
        }
    }

    printf("\n");

    for(l=0; l<2; l++){
        for(c=0; c<3; c++){
            printf("Digite a matriz D [%i][%i]: ", l, c);
            scanf("%d", &matrizD[l][c]);
        }
    }

    printf("\n");

    for(l=0; l<2; l++){
        for(c=0; c<3; c++){
            for(v=0; v<4; v++){
                matrizAD[l][c] = 0;
                matrizAD[l][c] += matrizA[l][c] * matrizD[c][l];
           }
        }
    }

    printf("\n");

    for(l=0; l<2; l++){
        for(c=0; c<3; c++){
            printf("O valor da matriz AD [%i][%i]: %d\n", l, c, matrizAD[l][c]);
        }
    }


    return 0;
}