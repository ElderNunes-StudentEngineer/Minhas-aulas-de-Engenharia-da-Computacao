#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
1) Crie um programa para armazenar 10 nomes em um vetor
e imprimir uma lista numerada
*/

int main(){

    char nome[11][21];
    int contador = 1;

    for(int l=0; l<10; l++){
        printf("Digite o nome: ");
        scanf("%20[^\n]", &nome[l]);
        setbuf(stdin, NULL);

    }

    for(int l=0; l<10; l++){
        
        printf("%d-%s\n", contador, nome[l]);
        contador++;
    }





    return 0;
}