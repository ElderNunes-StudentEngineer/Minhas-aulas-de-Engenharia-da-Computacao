#include<stdio.h>
#include<stdlib.h>

int main(){

    int num1, num2, result1, num3, num4, result2, num5, num6, result3, num7, num8, result4;
    char operacao;

    printf("Menu de opções:\n");
    printf("+ - Adição\n");
    printf("- - Subtração\n");
    printf("* - Multiplicação\n");
    printf("/ - Divisão\n");
    printf("Digite a operação: \n");
    scanf("%c", &operacao);


    switch (operacao){

        case '+' :
            printf("Digite o primeiro número: \n");
            scanf("%i", &num1);
            printf("Digite o segundo número: \n");
            scanf("%i", &num2);

            result1 = num1 + num2;

            printf("O resultado da operação é: %i\n", result1);
            break;
        case '-':
            printf("Digite o primeiro número: \n");
            scanf("%i", &num3);
            printf("Digite o segundo número: \n");
            scanf("%i", &num4);

            result2 = num3 - num4;

            printf("O resultado da operação é: %i\n", result2);
            break;
        case '*':
            printf("Digite o primeiro número: \n");
            scanf("%i", &num5);
            printf("Digite o segundo número: \n");
            scanf("%i", &num6);

            result3 = num5 * num6;

            printf("O resultado da operação é: %i\n", result3);
            break;
        case '/':
            printf("Digite o primeiro número: \n");
            scanf("%i", &num7);
            printf("Digite o segundo número: \n");
            scanf("%i", &num8);

            result4 = num7 / num8;

            printf("O resultado da operação é: %i\n", result4);
            break;
        default:
            printf("Operação Inválida!\n");
    }


  
}