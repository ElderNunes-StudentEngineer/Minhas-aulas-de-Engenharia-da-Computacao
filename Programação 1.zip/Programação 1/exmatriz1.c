#include<stdio.h>
#include<stdlib.h>

/*
1) Crie uma matriz identidade com dimensões 5 x 5;
*/

int main(){

    int l, c;
    int matriz[5][5];

    for(l=0; l<5; l++){
        for(c=0; c<5; c++){
            if(l==c){
                matriz[l][c] = 1;
            }else{
                matriz[l][c] = 0;
            }
        }
    }

    for(l=0; l<5; l++){
        for(c=0; c<5; c++){
                printf("%2d ", matriz[l][c]);
        
        }
        printf("\n");
    }

    return 0;
}