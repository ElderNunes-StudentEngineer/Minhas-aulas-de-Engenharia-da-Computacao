#include <stdio.h>

int main() {
    int Z;

    // Solicita ao usuário inserir um número positivo
    printf("Digite um número positivo: ");
    scanf("%d", &Z);

    // Verifica se o número inserido é positivo
    if (Z <= 0) {
        printf("Por favor, insira um número positivo.\n");
        return 1; // Retorna código de erro
    }

    // Imprime todos os números de Z até 1
    printf("Números de %d até 1:\n", Z);
    for (int i = Z; i >= 1; i--) {
        printf("%d ", i);

        // Verifica se o número atual é múltiplo de 4
        if (i % 4 == 0) {
            printf("(múltiplo de 4) ");
        }

        // Verifica se o número atual é múltiplo de 3
        if (i % 3 == 0) {
            printf("(múltiplo de 3) ");
        }

        printf("\n");
    }

    // Variáveis para contagem de múltiplos de 3 e soma dos múltiplos de 5
    int countMultiplos3 = 0;
    int sumMultiplos5 = 0;
    int countMultiplos5 = 0;

    // Calcula a média dos números múltiplos de 5
    for (int i = Z; i >= 1; i--) {
        if (i % 5 == 0) {
            sumMultiplos5 += i;
            countMultiplos5++;
        }
    }

    // Calcula a média dos números múltiplos de 5
    float mediaMultiplos5 = 0;
    if (countMultiplos5 > 0) {
        mediaMultiplos5 = (float)sumMultiplos5 / countMultiplos5;
    }

    // Exibe resultados finais
    printf("\nQuantidade de números múltiplos de 4: %d\n", Z / 4);
    printf("Quantidade de números múltiplos de 3: %d\n", countMultiplos3);
    printf("Média dos números múltiplos de 5: %.2f\n", mediaMultiplos5);

    return 0; // Retorna código de sucesso
}