#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main() {

    setlocale(LC_ALL, "Portuguese");

    int idade;
    float salario;
    char bloco;

    printf("Digite sua idade: ");
    scanf("%d", &idade);
    printf("Sua idade é: %d anos\n", idade);

    setbuf(stdin,NULL);

    printf("Digite o bloco da sua aula: ");
    scanf("%c", &bloco);
    printf("Seu bloco é: %c\n", bloco);

    printf("Digite seu salario: ");
    scanf("%f", &salario);
    printf("Seu salario é de r$: %.2f\n", salario);



    return 0;


}