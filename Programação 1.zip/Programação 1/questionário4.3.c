#include<stdio.h>
#include<stdlib.h>

int main() {

    int a = 40;
    int b = -1;
    float soma = a + b;
    float sub = a - b;
    float mult = a * b;
    float div = a / b;
    printf("A soma dos dois valores é: %.f\n", soma);
    printf("A subtração dos dois valores é: %.f\n", sub);
    printf("A multiplicação dos dois valores é: %.f\n", mult);
    printf("A divisão dos dois valores é: %.f\n", div);
    

}