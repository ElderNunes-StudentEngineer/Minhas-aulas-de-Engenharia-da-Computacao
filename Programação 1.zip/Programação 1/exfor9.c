#include<stdio.h>
#include<stdlib.h>

int main(){

    int tamanho;

    printf("Digite um tamanho: ");
    scanf("%d", &tamanho);

    for(int tamanho1 = 1; tamanho1 <= tamanho; tamanho1++){
       for(int tamanho2 = 1; tamanho2 <= tamanho; tamanho2++){
        printf("#");
       }
       printf("\n");
    }




    return 0;
}