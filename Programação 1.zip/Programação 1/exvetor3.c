#include<stdio.h>
#include<stdlib.h>

/*
Leia um vetor A com 10 elementos inteiros correspondentes as idades de um grupo de pessoas. Escreva um programa que determine e escreva a quantidade de pessoas que possuem idade superior a 35 anos
*/

int main(){

int vetorA[10];
int i;
int contador = 0;

for(i=0; i<10; i++){
    printf("Digite sua idade: \n");
    scanf("%d", &vetorA[i]);

    if(vetorA[i] > 35){
        contador++;
    }
}

printf("%d pessoas tem idade mais que 35.\n", contador);





    return 0;
}