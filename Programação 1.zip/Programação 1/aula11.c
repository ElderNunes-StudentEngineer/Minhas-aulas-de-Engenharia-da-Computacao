#include<stdio.h>
#include<stdlib.h>

int main(){

    int notas[5];
    int i;

    for(i=0; i<5; i++){

        printf("Informe a %d nota: ", i);
        scanf("%d", &notas[i]);

    }

        printf("\n As notas informadas foram: \n");
        for (i=0; i < 5; i++){
        printf("Nota[%d]: %d \n", i, notas[i]);

        }

    return 0;
}