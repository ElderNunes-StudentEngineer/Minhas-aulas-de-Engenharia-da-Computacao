#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/*
 Faça um programa que receba e armazene 20 números em 
um vetor. Em seguida exiba:
 Quantos números são iguais a 30;
 Quantos números são maiores que a média;
 Quantos números são iguais à média;
*/

int main() {
    setlocale(LC_ALL, "");

    int vetor[20];
    int i;
    int contador30 = 0;
    int contadorMaiorMedia = 0;
    int contadorIgualMedia = 0;
    int soma = 0;

    for (i = 0; i < 20; i++) {
        printf("Digite o valor %d do vetor: ", i);
        scanf("%d", &vetor[i]);

        soma += vetor[i];
    }

    float media = (float)soma / 20;

    for (i = 0; i < 20; i++) {
        if (vetor[i] == 30) {
            contador30++;
        } else if (vetor[i] > media) {
            contadorMaiorMedia++;
        } else if (vetor[i] == media) {
            contadorIgualMedia++;
        }
    }

    printf("%d números são iguais a 30.\n", contador30);
    printf("%d números são maiores que a média.\n", contadorMaiorMedia);
    printf("%d números são iguais à média.\n", contadorIgualMedia);

    return 0;
}
