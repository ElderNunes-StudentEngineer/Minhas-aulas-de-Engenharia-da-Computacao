#include<stdio.h>
#include<stdlib.h>

/*
3) Construa um programa que leia uma matriz de tamanho
5 x 5 e escreva:
 O valor e a localização (linha, coluna) do maior valor encontrado
na matriz.
*/

int main(){

    int l, c;
    int matriz[5][5];
    int maior = 0;
    int linha, coluna;

    for(l=0; l<5; l++){
        for(c=0; c<5; c++){
            printf("Digite o valor da matriz[%i][%i]: ", l, c);
            scanf("%d", &matriz[l][c]);
            if(matriz[l][c] >= maior){
                maior = matriz[l][c];
                linha = l + 1;
                coluna = c + 1;
            }
        }
    }

    printf("O maior valor da matriz é: %d, na Linha %d  e na Coluna %d.\n", maior, linha, coluna);


    return 0;
}