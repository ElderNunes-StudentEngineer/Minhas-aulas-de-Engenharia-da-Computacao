#include<stdio.h>
#include<stdlib.h>

int main() {

    int dia, mes, ano;

    printf("Digite a data de hoje: ");
    scanf("%d/%d/%d", &dia,&mes,&ano);

    printf("Hoje é %02d/%02d/%04d\n", dia,mes,ano);

    return 0;
}