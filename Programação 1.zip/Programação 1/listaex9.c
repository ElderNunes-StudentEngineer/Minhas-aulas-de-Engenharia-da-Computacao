#include<stdio.h> 
#include<stdlib.h>

int main(){

    int dia, mes, ano;

    if(dia <= 31 && mes <=12){
        printf("Digite o dia: \n");
        scanf("%d", &dia);
        printf("Digite o mês: \n");
        scanf("%d", &mes);
        printf("Digite o ano: \n");
        scanf("%d", &ano);
        printf("A data é válida!\n");
        printf("A data é: %d/%d/%d\n", dia, mes, ano);
    }else{
        printf("Data Inválida!\n");
    }











    return 0;
}