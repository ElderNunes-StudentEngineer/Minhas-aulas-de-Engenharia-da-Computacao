#include<stdio.h>
#include<stdlib.h>
/*
1) Faça um algoritmo que implemente uma função que receba 3 números
inteiros e retorne o maior valor, se algum for negativo retorne -1;
*/
int maiorValor(int valor1, int valor2, int valor3){
    int maior;

    if(valor1 < 0 || valor2 < 0 || valor3 < 0){
        return -1;
    }
    if(valor1 >= valor2 && valor1 >= valor3){
        maior = valor1;
    }else if(valor2 >= valor1 && valor2 >= valor3){
        maior = valor2;
    }else{
        maior = valor3;
    }

    return maior;
}
int main(){

    int maiorRetornado;
    int meuValor1;
    int meuValor2;
    int meuValor3;

    printf("Digite o valor1: ");
    scanf("%d", &meuValor1);

    printf("Digite o valor2: ");
    scanf("%d", &meuValor2);

    printf("Digite o valor3: ");
    scanf("%d", &meuValor3);



    maiorRetornado = maiorValor(meuValor1, meuValor2, meuValor3);
    printf("O maior valor é %d\n", maiorRetornado);
    return 0;
}    
