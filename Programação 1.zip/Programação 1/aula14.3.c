#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char** argv){

    int idade;
    printf("Foram recebidos: %d argumentos\n", argc);

    for(int i=0; i<argc; i++){
        printf("Argumento %d: %s\n", i, argv[i]);
    }


    strtol(argv[1], &idade, 10);
    idade = atoi(argv[1]);

    return 0;
}//main