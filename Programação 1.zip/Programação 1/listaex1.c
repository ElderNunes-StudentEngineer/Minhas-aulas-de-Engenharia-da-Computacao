#include<stdio.h>
#include<stdlib.h>

int main(){

    float salariominimo, quilo, umquartosalario, cadaquilo, quilogasto, novovalor, valorcomdesconto;

    printf("Digite o valor do salário mínimo: \n");
    scanf("%f", &salariominimo);
    printf("Digite a quantidade de quilowatts gasta pela residência: \n");
    scanf("%f", &quilo);

    umquartosalario = salariominimo * 0.25;
    cadaquilo = umquartosalario/200;

    printf("O valor de cada quilowatts é: %.2f reais\n", cadaquilo);

    quilogasto = quilo * cadaquilo;

    printf("O valor gasto em energia pela residência é: %.2f reais\n", quilogasto);

    novovalor = quilogasto * 0.12;
    valorcomdesconto = quilogasto - novovalor;

    printf("O novo valor gasto pela residência é: %.2f reais\n", valorcomdesconto);






}