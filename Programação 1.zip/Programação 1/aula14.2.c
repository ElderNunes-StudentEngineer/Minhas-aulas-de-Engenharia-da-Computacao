#include<stdio.h>
#include<stdlib.h>

void duplicaVetor(int vetor[], int tamanho){
    for(int i=0; i<tamanho; i++){
        vetor[i] *= 2; 
    }//for
    return;
}//duplicaVetor



int main(){

    int meuvetor[5] = {10,20,30,40,50};

    printf("Vetor antes da função:\n");
    for(int i=0; i<5; i++){
        printf("%d, ",meuvetor[i]);
    }

    duplicaVetor(meuvetor,5);

    printf("\nVetor depois da função:\n");
    for(int i=0; i<5; i++){
        printf("%d, ",meuvetor[i]);
    }

    return 0;
}