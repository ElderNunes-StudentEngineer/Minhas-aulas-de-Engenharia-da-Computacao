#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main() {

    float mes1, mes2, mes3;

    float t1 = 500 * 0.01;
    mes1 = 500 + t1;
    float t2 = mes1*0.01;
    mes2 = t2 + mes1;
    float t3 = mes2*0.01;
    mes3 = t3 + mes2;

    printf("O valor da conta após 3 meses é: %.2f reais\n", mes3);


}