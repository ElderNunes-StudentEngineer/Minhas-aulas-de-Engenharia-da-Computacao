#include<stdio.h>
#include<stdlib.h>

/*
 4) Faça um programa que multiplique por 5 a
matriz A (preenchida a partir do teclado) para gerar a
matriz C.
*/

int main(){

    int l, c;
    int matrizA[3][3];
    int matrizB[3][3];

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("Digite a matriz A [%i][%i]: ", l, c);
            scanf("%d", &matrizA[l][c]);

        }
    }

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            matrizB[l][c] = 5 * matrizA[l][c];
        }
    }

    printf("\n");

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("Valor da matriz B [%i][%i]: %d\n",l,c,matrizB[l][c]);
        }
    }



    return 0;
}


