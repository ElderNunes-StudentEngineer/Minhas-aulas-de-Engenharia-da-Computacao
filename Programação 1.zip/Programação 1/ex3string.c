#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
3) Desenvolva um programa que armazene o nome e o
telefone de 5 pessoas. Ao digitar a posição desejada, o
programa deve exibir o nome e telefone daquela posição. O
programa finaliza ao receber a entrada -1.
*/

int main(){

    char nome[5][21];
    int telefone[5];
    int posicao;

    for(int n=0; n<5; n++){
        setbuf(stdin, NULL);
        printf("Digite seu nome: ");
        scanf("%20[^\n]", &nome[n]);

        printf("Digite seu telefone: ");
        scanf("%d", &telefone[n]);

    }

        printf("Digite a posição desejada: ");
        printf("Menu de opções:\n");
        printf("Posição - 1\n");
        printf("Posição - 2\n");
        printf("Posição - 3\n");
        printf("Posição - 4\n");
        printf("Posição - 5\n");
        printf("Digite a posição desejada: ");


        scanf("%d", &posicao);

        switch (posicao){

            case 1:
                printf("1- %s - %f\n", nome[0], telefone[0]);
                break;
            case 2:
                printf("2- %s - %f\n", nome[1], telefone[1]);
                break;
            case 3:
                printf("3- %s - %f\n", nome[2], telefone[2]);
                break;
            case 4:
                printf("4- %s - %f\n", nome[3], telefone[3]);
                break;
            case 5:    
                printf("5- %s - %f\n", nome[4], telefone[4]);    
                break;
            default:
                break;


        }





    return 0;
}