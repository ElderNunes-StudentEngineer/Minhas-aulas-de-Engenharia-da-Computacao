#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/*
Dado dois vetores, A (4 elementos) e B (5 elementos), faça 
um programa em C que imprima todos os elementos comuns 
aos dois vetores.
*/

int main(){
	
	setlocale(LC_ALL, "");
	
	int vetorA[4];
	int vetorB[5];
	int j;
	int i;
	
	for(i=0; i<4; i++){
		printf("Digite o valor %d do vetor A: ", i);
		scanf("%d", &vetorA[i]);
	}
	for(i=0; i<5; i++){
		printf("Digite o valor %d do vetor B: ", i);
		scanf("%d", &vetorB[i]);
    }
	
	printf("Os elementos comuns são: \n");
	
	for(i=0; i<4; i++){
		for(j=0; j<5; j++){
			if(vetorA[i] == vetorB[j]){
				printf("%d\n", vetorA[i]);
			}
		}
	}
	
	
	
	
	
	return 0;
}