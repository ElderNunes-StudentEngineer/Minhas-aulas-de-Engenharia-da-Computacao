#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

int main(){

    setlocale(LC_ALL, "Portuguese");

    float altura, peso_ideal;

    printf("Digite sua altura: ");
    scanf("%f", &altura);

    peso_ideal = (72.7 * altura - 58);

    printf("Seu peso ideal é: %.2f\n", peso_ideal);
}