#include<stdio.h>
#include<stdlib.h>

int main(){

    int n1, n2, nf;

    for(n1 = 0, n2 = 1; n1 >= 0; n1++, n2++){
        nf = (n1-1) + (n2-2);
        printf("A sequência é: %d\n", nf);
    }




    return 0;
}