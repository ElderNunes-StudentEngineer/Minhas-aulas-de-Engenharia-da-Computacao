#include<stdio.h>
#include<stdlib.h>

/*
 2) Faça um algoritmo que leia uma matriz 3 por 3 (3x3) e
retorna a soma dos elementos da sua diagonal principal e
da sua diagonal secundária;
*/

int main(){

    int l, c;
    int matriz[3][3];
    int diagonal = 0;
    int diagonalsec = 0;
    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            printf("Digite o valor da matriz[%i][%i]: ", l, c);
            scanf("%d", &matriz[l][c]);
            if(l == c){
                diagonal += matriz[l][c];
            }
        }
    }

    for(l=0; l<3; l++){
        for(c=0; c<3; c++){
            if(l + c == 3 - 1){
                diagonalsec += matriz[l][c];
            }
        }
    }

    printf("A soma da diagonal principal é %d\n", diagonal);
    printf("A soma da diagonal secundária é %d\n", diagonalsec);

    return 0;
}