#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/*
Faça um programa que leia e armazene dois vetores de tamanho 5. Ao final o programa deve calcular e exibir o vetor soma;
*/

int main() {
    setlocale(LC_ALL, "");

    int vetor1[5];
    int vetor2[5];
    int vetorSoma[5]; 
    int i;

    for (i = 0; i < 5; i++) {
        printf("Digite o valor %d do vetor 1: \n", i);
        scanf("%d", &vetor1[i]);
    }

    for (i = 0; i < 5; i++) {
        printf("Digite o valor %d do vetor 2: \n", i);
        scanf("%d", &vetor2[i]);
    }

    for (i = 0; i < 5; i++) {
        vetorSoma[i] = vetor1[i] + vetor2[i];
    }

    printf("Vetor Soma:\n");
    for (i = 0; i < 5; i++) {
        printf("%d ", vetorSoma[i]);
    }
    printf("\n");

    return 0;
}
