#include<stdio.h>
#include<stdlib.h>

/*
1) Faça um algoritmo que implemente uma função que receba 3 números
inteiros e retorne o maior valor;
*/

int main(){

    

    return 0;
}