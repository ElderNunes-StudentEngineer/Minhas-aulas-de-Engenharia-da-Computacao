#include<stdio.h>
#include<stdlib.h>

int main() {

    int idade, ano_nasceu, ano_atual, idade_atual;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    printf("Digite o ano em que nasceu: ");
    scanf("%d", &ano_nasceu);

    printf("Digite o ano atual: ");
    scanf("%d", &ano_atual);

    idade_atual = (ano_atual - ano_nasceu);

    printf("Sua idade atual é: %d\n", idade_atual);




    
}