#include<stdio.h>
#include<stdlib.h>

int main(){

    float vm = 80;
    float tempogasto = 35;
    float temp;
    float quantlitros;
    temp = vm * tempogasto;
    temp = temp/60;
    quantlitros = temp/12;

    printf("A quantiadade de litros é de aproximadamente: %.0f litros\n", quantlitros);




}