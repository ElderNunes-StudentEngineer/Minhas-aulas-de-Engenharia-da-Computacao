#include<stdio.h>
#include<stdlib.h>

/*
1) Crie um algoritmo que imprima uma tabela de conversão de polegadas para centímetros. Deseja-se que na tabela conste valores de 1 polegada até 20 polegadas inteiras. (Para isso considere: 1 polegada = 2,54 cm)
Exemplo de saída:
1” equivale a 2,54 cm
2” equivalem a 5,08 cm
3” equivalem a 7,62 cm
*/

int main(){

    float polegadas = 2.54;
    int contador = 1;
    for(int i=0; i<20; i++){
        printf("%d - equivalem a %.2f cm\n", contador, polegadas);
        polegadas += polegadas;
        contador++;
    }






    return 0;
}