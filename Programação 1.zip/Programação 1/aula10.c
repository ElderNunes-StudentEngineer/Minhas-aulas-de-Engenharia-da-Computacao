#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){

    
/*
    int numero = 1;
    while(numero <= 100){
        printf("O número é: %d\n", numero);
        numero++;


    }//while
*/
    for(int numero = 1; numero <= 100; numero++){
        printf("O número é: %d\n", numero);
    }//for

    int x;
    int y;

    for(x = 1; x <= 10; x++){
        for(y = 1; y <= 10; y++){
            printf("X: %d e Y: %d\n", x, y);
            fflush(stdout); //mostrar imediatamente na tela
            usleep(200000);// Mostra devagar
        }
    }




    return 0;
}