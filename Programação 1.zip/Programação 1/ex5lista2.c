#include<stdio.h>
#include<stdlib.h>
/*
5) Faça um programa que receba 10 números inteiros. Em seguida o programa deverá permitir o usuário buscar números dentro do vetor, informando se o mesmo está ou não no vetor. O usuário poderá realizar quantas buscas quiser e finalizar ao solicitar a busca de um valor negativo.
*/
int main(){

    int vetor[10];
    int j;
    for(int i=0; i<10; i++){
        printf("Digite o Vetor: ");
        scanf("%d", &vetor[i]);
    }
    
    printf("Digite o número buscado: ");
    scanf("%d", &j);
    for(int i=0; i<10; i++){
   

        if(j == vetor[i]){
            printf("Está no vetor.\n");
        }else if(j != vetor[i]){
            printf("Não está no vetor.\n");
        }
    }

    return 0;
}