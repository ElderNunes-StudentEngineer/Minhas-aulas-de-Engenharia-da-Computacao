#include<stdio.h>
#include<stdlib.h>

void divide(int dividendo, int divisor, int* quociente, int* resto){
    *quociente = dividendo/divisor;
    *resto = dividendo % divisor;
}//divide

int main(){

    int dividendo = 13;
    int divisor = 5;
    int quociente;
    int resto;

    divide(dividendo, divisor, &quociente, &resto);
    printf("O quociente é: %d e o resto: %d\n", quociente, resto);
    return 0;
}//main