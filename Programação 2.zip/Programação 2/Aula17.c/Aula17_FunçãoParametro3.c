#include<stdio.h>
#include<stdlib.h>

void incrementaVetor(int vetor[]){
    for(int i=0; i<10; i++){
        vetor[i]++;
    }//for
}//incrementaVetor

int main(){

    int meuVetor[10] = {10, 11, 12, 13, 14, 15, 16, 17, 18, 19};
    printf("Antes da função:\n");
    for(int i=0; i<10; i++){
        printf("Vetor[%d]= %d\n", i, meuVetor[i]);
    }//for

    incrementaVetor(meuVetor);

    printf("\nDepois da função:\n");
    for(int i=0; i<10; i++){
        printf("Vetor[%d]= %d\n", i, meuVetor[i]);
    }//for

    return 0;
}//main