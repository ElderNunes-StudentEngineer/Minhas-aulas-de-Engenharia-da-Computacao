#include<stdio.h>
#include<stdlib.h>
/*
Reescreva o exercício anterior utilizando a estrutura horário (contendo hora, minuto e segundo) e passando a estrutura por referência. 
Utilize o seguinte protótipo da função:
void converteHorario(int total_segundos, Horario* hor)
*/

typedef struct{
    int hora, minuto, segundo;
}Horario;

void converteHorario(int total_segundos, Horario* hor){
    hor -> hora = total_segundos/3600;
    hor -> minuto =(total_segundos / 60) %60;
    hor -> segundo = total_segundos % 60;
    return;
}//converteHorario

int main(){

    Horario horario;
    int total_segundos;

    printf("Digite o número total de segundos a ser convertidos:");
    scanf("%d", &total_segundos);

    converteHorario(total_segundos,&horario);

    printf("Conversão: %02d:%02d:%02d\n", horario.hora, horario.minuto, horario.segundo);
    
    return 0;
}//main