#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Crie um Sistema de Gerenciamento de Bandas seguindo os seguintes passos:
a) Defina uma estrutura que irá representar bandas de música. 
Essa estrutura deve ter o nome da banda, que tipo de música ela toca, 
o número de integrantes e em que posição do ranking essa banda está dentre as suas 5 bandas favoritas;
b) Crie uma função para preencher as 5 estruturas de bandas criadas no exemplo passado. 
Após criar e preencher, exiba todas as informações das bandas/estruturas.
c) Crie uma função que peça ao usuário um número de 1 até 5. 
Em seguida, seu programa deve exibir informações da banda cuja posição no seu ranking é a que foi solicitada pelo usuário;
d) Crie uma função que peça ao usuário um tipo de música e exiba as bandas com esse tipo de música no seu ranking.
e) Crie uma função que peça o nome de uma banda ao usuário e diga se ela está entre suas bandas favoritas ou não;
f) Agora junte tudo e crie um menu com as opções de preencher as estruturas e todas as opções das questões passadas.
*/

/*
a) Defina uma estrutura que irá representar bandas de música. 
Essa estrutura deve ter o nome da banda, que tipo de música ela toca, 
o número de integrantes e em que posição do ranking essa banda está dentre as suas 5 bandas favoritas;
*/

typedef struct{
    char nomeBanda[21];
    char tipoMusica[21];
    int numIntegrantes;
    int posiRank;
}Bandas;

/*
b) Crie uma função para preencher as 5 estruturas de bandas criadas no exemplo passado. 
Após criar e preencher, exiba todas as informações das bandas/estruturas.
*/

void PreencherBandas(Bandas* banda){
	int i;
	for(i=0; i<5; i++){
	printf("Digite o nome da banda %d:", i+1);
    scanf("%20[^\n]", banda[i].nomeBanda);
    setbuf(stdin, NULL);

    printf("Digite o tipo de música da banda:");
    scanf("%20[^\n]", banda[i].tipoMusica);

    printf("Digite o número de integrantes da banda:");
    scanf("%d", &banda[i].numIntegrantes);
    
    printf("Digite a posição da banda no ranking (de suas bandas 5 favoritas):");
    scanf("%d", &banda[i].posiRank);
    setbuf(stdin, NULL);
    printf("\n\n");
	}//for
}//PreencherBandas

void ExibirBandas(Bandas* banda){
	int i;
	printf("\nInformações das bandas:\n");
    for (i = 0; i < 5; i++) {
        printf("\nBanda %d:\n", i + 1);
        printf("Nome: %s\n", banda[i].nomeBanda);
        printf("Tipo de música: %s\n", banda[i].tipoMusica);
        printf("Número de integrantes: %d\n", banda[i].numIntegrantes);
        printf("Posição no ranking: %d\n", banda[i].posiRank);
    }//for
}//ExibirBandas

/*
c) Crie uma função que peça ao usuário um número de 1 até 5. 
Em seguida, seu programa deve exibir informações da banda cuja posição no seu ranking é a que foi solicitada pelo usuário;
*/

void BuscaBanda(Bandas* bus){
	int busca;
	int i;
	printf("Digite um número de 1 a 5:");
	scanf("%d", &busca);
	setbuf(stdin, NULL);	
    if (busca >= 1 && busca <= 5) {
        printf("Nome: %s\n", bus[busca - 1].nomeBanda);
        printf("Tipo de música: %s\n", bus[busca - 1].tipoMusica);
        printf("Número de integrantes: %d\n", bus[busca - 1].numIntegrantes);
        printf("Posição no ranking: %d\n", bus[busca - 1].posiRank);
    } else {
        printf("Opção Inexistente!\n");
    }
}//BuscaBanda

/*
d) Crie uma função que peça ao usuário um tipo de música e exiba as bandas com esse tipo de música no seu ranking.
*/

void BuscaMus(Bandas* mus){
	char buscaMusica[21];
    int encontrou = 0;
    int i;

    printf("Digite um tipo de música:");
    scanf("%20[^\n]", buscaMusica);
    setbuf(stdin, NULL); 

    printf("\nBandas com o tipo de música '%s':\n", buscaMusica);

    for (i=0; i<5; i++) {
        if (strcmp(buscaMusica, mus[i].tipoMusica) == 0) {
            printf("\nNome: %s\n", mus[i].nomeBanda);
            printf("Tipo de música: %s\n", mus[i].tipoMusica);
            printf("Número de integrantes: %d\n", mus[i].numIntegrantes);
            printf("Posição no ranking: %d\n", mus[i].posiRank);
            encontrou = 1;
        }
    }

    if (!encontrou) {
        printf("\nNenhuma banda encontrada com o tipo de música '%s'.\n", buscaMusica);
    }
}//BuscaMus

/*
e) Crie uma função que peça o nome de uma banda ao usuário e diga se ela está entre suas bandas favoritas ou não;
*/

void BuscaNome(Bandas* nome){
	char BuscaNomeBanda[21];
	int i;
	int encontrou = 0;
	printf("Digite o nome da banda:");
	scanf("%20[^\n]", BuscaNomeBanda);
	setbuf(stdin, NULL);

    for (i=0; i<5; i++) {
        if (strcmp(BuscaNomeBanda, nome[i].nomeBanda) == 0) {
            encontrou = 1;
            break;
        }
    }//for
    
    if (encontrou) {
        printf("Está entre as favoritas!\n");
    } else {
        printf("Não está entre as favoritas!\n");
    }
}//BuscaNome

int main(){

    Bandas minhaBanda[5];
    int i;

   for(i=0; i<5; i++){
    printf("Digite o nome da banda %d:", i+1);
    scanf("%20[^\n]", minhaBanda[i].nomeBanda);
    setbuf(stdin, NULL);

    printf("Digite o tipo de música da banda:");
    scanf("%20[^\n]", minhaBanda[i].tipoMusica);

    printf("Digite o número de integrantes da banda:");
    scanf("%d", &minhaBanda[i].numIntegrantes);
    
    printf("Digite a posição da banda no ranking (de suas bandas 5 favoritas):");
    scanf("%d", &minhaBanda[i].posiRank);
    setbuf(stdin, NULL);
    printf("\n\n");
   }
   
   PreencherBandas(minhaBanda);
   ExibirBandas(minhaBanda);
   BuscaBanda(minhaBanda);
   BuscaMus(minhaBanda);
   BuscaNome(minhaBanda); 
   
   /*
   f) Agora junte tudo e crie um menu com as opções de preencher as estruturas e todas as opções das questões passadas
   */
   int opcao;
   
   do {
        printf("\n\n");
        printf("1. Exibir informações das bandas\n");
        printf("2. Buscar banda por número de ranking\n");
        printf("3. Buscar bandas por tipo de música\n");
        printf("4. Verificar se uma banda está entre as favoritas\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        printf("\n");

        switch(opcao) {
            case 1:
                ExibirBandas(minhaBanda);
                break;
            case 2:
                BuscaBanda(minhaBanda);
                break;
            case 3:
                BuscaMus(minhaBanda);
                break;
            case 4:
                BuscaNome(minhaBanda);
                break;
            case 0:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida!\n");
        }
    } while (opcao != 0);


    return 0;
}//main