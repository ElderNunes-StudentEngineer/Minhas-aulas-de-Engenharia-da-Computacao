#include<stdio.h>
#include<stdlib.h>

/*
Escreva um programa que receba um número inteiro representando a quantidade total de segundos e, 
usando passagem de parâmetros por referência, converta a quantidade informada de segundos em Horas, Minutos e Segundos.
Imprima o resultado da conversão no formato HH:MM:SS. Utilize o seguinte protótipo da função:
void converteHora(int total_segundos, int* hora, int* min, int* seg)
*/

void converteHora(int total_segundos, int* hora, int* min, int* seg){
    if(total_segundos > 0){
    *hora = total_segundos/3600;
    *min = (total_segundos/60) %60;
    *seg = total_segundos %60;
    }
}//converteHora 

int main(){

    int total_segundos;
    int hora, min, seg;

    printf("Digite a quantidade de números positivos(em segundos):");
    scanf("%d", &total_segundos);
    converteHora(total_segundos, &hora, &min, &seg);
    if(total_segundos > 0){
    printf("Coversão: %02d:%02d:%02d\n", hora, min, seg);
    }
    return 0;
}//main