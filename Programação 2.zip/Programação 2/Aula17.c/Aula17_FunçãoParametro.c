#include<stdio.h>
#include<stdlib.h>

void incrementaNumero(int* numero){
    (*numero)++;
    printf("O ponteiro para o número é: %p\n", numero);
    return;
}//incrementa

int main(){

    int numero;

    printf("Digite seu número: ");
    scanf("%d", &numero);

    incrementaNumero(&numero);
    printf("O número da main é: %d\n", numero);

    return 0;
}//main