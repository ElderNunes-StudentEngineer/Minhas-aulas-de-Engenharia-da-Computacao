#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Escreva um trecho de código para fazer a criação dos novos tipos de dados conforme solicitado abaixo:
• Horário: composto de hora, minutos e segundos.
• Data: composto de dia, mês e ano.
• Compromisso: local,data, horário e texto que descreve o compromisso.
*/

typedef struct{
    int hora;
    int minutos; 
    int segundos;
}Horario;//struct

typedef struct{
    int dia;
    int mes; 
    int ano;
}Data;//struct

typedef struct{
    char local[101];
    Data data;
    Horario horario;
    char descricao[101];
}Compromisso;//struct

int main(){

    Compromisso meuCompromisso;
 
    printf("Digite o horário:");
    scanf("%d:%d:%d", &meuCompromisso.horario.hora, &meuCompromisso.horario.minutos, &meuCompromisso.horario.segundos);

    printf("Digite a Data:");
    scanf("%d/%d/%d", &meuCompromisso.data.dia, &meuCompromisso.data.mes, &meuCompromisso.data.ano);
    setbuf(stdin, NULL);

    printf("Digite o local:");
    scanf("%100[^\n]%*c", meuCompromisso.local);

    printf("Digite a descrição:");
    scanf("%100[^\n]%*c", meuCompromisso.descricao);

    printf("Descrição: %s\n", meuCompromisso.descricao);
    printf("Local: %s\n", meuCompromisso.local);
    printf("Data: %02d/%02d/%04d\n", meuCompromisso.data.dia, meuCompromisso.data.mes, meuCompromisso.data.ano);
    printf("Horário: %02d:%02d:%02d\n", meuCompromisso.horario.hora, meuCompromisso.horario.minutos, meuCompromisso.horario.segundos);

    return 0;
}//main