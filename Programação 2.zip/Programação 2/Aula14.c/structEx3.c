#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

/*
3) Construa uma estrutura aluno com nome, curso e 4 notas,
média e situação. Leia as informações nome, curso e notas do
teclado, calcule a média e armazene a situação do aluno.
? media >= 7  Aprovado;
? 3 =< media < 7  Exame;
? media < 3  Reprovado;
*/

struct Situacao{
	
	char nome[21];
	char curso[50];
	float nota1, nota2, nota3, nota4;
	
};//struct

int main(){
	
	setlocale(LC_ALL, "");
	int i;
	
	struct Situacao aluno;
	
	printf("Digite seu nome:");
	scanf("%20[^\n]", aluno.nome);
	setbuf(stdin, NULL);
	
	printf("Digite seu curso:");
	scanf("%49[^\n]", aluno.curso);
	
	printf("Digite sua primeira nota:");
	scanf("%f", &aluno.nota1);
	
	printf("Digite sua segunda nota:");
	scanf("%f", &aluno.nota2);
	
	printf("Digite sua terceira nota:");
	scanf("%f", &aluno.nota3);
	
	printf("Digite sua quarta nota:");
	scanf("%f", &aluno.nota4);	
	
	float media = (aluno.nota1 + aluno.nota2 + aluno.nota3 + aluno.nota4)/4;
	
	printf("Sua média é: %.2f\n", media);
	
	if(media >= 7){
		printf("APROVADO!");
	}else if(media >= 3 && media < 7){
		printf("Você está de Exame!");
	}else{
		printf("REPROVADO!");
	}
	
	
	
	
	return 0;
}//main