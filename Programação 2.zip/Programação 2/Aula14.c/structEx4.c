#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

/*
4) Faça um programa que controla o consumo de energia dos
eletrodomésticos de uma casa e:
? Crie e leia 5 eletrodomésticos que contém nome (máximo 15 letras),
potência (real, em kW) e tempo ativo por dia (real, em horas).
? Leia um tempo t (em dias), calcule e mostre o consumo total na casa e
o consumo relativo de cada eletrodoméstico (consumo/consumo total)
nesse período de tempo. Apresente este último dado em porcentagem.
*/

struct Consumo{
		
	char nome[16];
	float potencia;
	float tempo;
	
};//struct

int main(){
	
	setlocale(LC_ALL, "");
	int i;
	float consumo_total = 0.0;
    float consumo_relativo[5] = {0.0};
	
	struct Consumo eletrodomesticos[5];
	
	for(i=0; i<5; i++){
		printf("Digite o nome do Eletrodoméstico %d:", i+1);
		scanf("%16[^\n]", eletrodomesticos[i].nome);
		
		printf("Digite a potência do eletrodomético %d (em kw):", i+1);
		scanf("%f", &eletrodomesticos[i].potencia);
		
		printf("Digite o tempo ativo por dia do eletrodomético %d (em horas):", i+1);
		scanf("%f", &eletrodomesticos[i].tempo);
		setbuf(stdin, NULL);
		
		consumo_total += eletrodomesticos[i].potencia * eletrodomesticos[i].tempo;
	}//for
	
	for(i=0; i<5; i++){
		consumo_relativo[i] = (eletrodomesticos[i].potencia  *  eletrodomesticos[i].tempo)/consumo_total * 100;
	}//for
	
	printf("\nConsumo total na casa: %.2f kW\n", consumo_total);
    printf("Consumo relativo de cada eletrodoméstico:\n");
    for(i = 0; i < 5; i++) {
        printf("%s: %.2f%%\n", eletrodomesticos[i].nome, consumo_relativo[i]);
    }//for
	
	return 0;
}//main