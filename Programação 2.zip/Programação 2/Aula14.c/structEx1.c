
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

/*
1) Crie uma estrutura para representar as coordenadas de
um ponto no plano (posições X e Y). Em seguida, declare
e leia do teclado dois pontos e exiba a distância entre
eles.
*/

typedef struct{
    
    float x;
    float y;

}Coordenadas; //struct

int main(){

    Coordenadas ponto1;
    Coordenadas ponto2;

    printf("Ponto 1\n");
    printf("X:");
    scanf("%f", &ponto1.x);
    printf("Y:");
    scanf("%f", &ponto1.y);

    printf("Ponto 2\n");
    printf("X:");
    scanf("%f", &ponto2.x);
    printf("Y:");
    scanf("%f", &ponto2.y);

    float distancia = sqrt(pow(ponto2.x - ponto1.x, 2) + pow(ponto2.y - ponto1.y, 2));

    printf("A distância é: %.2f\n", distancia);

    return 0;
}