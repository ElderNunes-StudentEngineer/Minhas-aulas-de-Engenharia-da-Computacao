#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
    
    FILE* arquivo = fopen("dados.txt", "r");
    char frase[50];
    char c;
    int i=0;
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    while((c = fgetc(arquivo)) != EOF){
        frase[i] = c;
        i++;
    }//for
    frase[i]='\0';

    printf("Dados lidos: %s\n", frase);

    fclose(arquivo);
    
    return 0;
}//main