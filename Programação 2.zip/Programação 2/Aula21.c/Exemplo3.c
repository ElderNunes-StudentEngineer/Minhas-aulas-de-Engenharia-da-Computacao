#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

    FILE* arquivo = fopen("dadosString.txt", "a");
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char frase[50] = "Sextou!";

    //char frase[50] = "Agora eu escrevo String no HD!!! =)";
    //fputs(frase,arquivo); escreve string

    fgets(frase, 50, arquivo);

    printf("Dados lidos: %s\n", frase);

    fclose(arquivo);

    return 0;
}//main