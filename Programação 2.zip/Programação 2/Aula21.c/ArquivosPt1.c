#include<stdio.h>
#include<stdlib.h>

int main(){

    FILE* arquivo = fopen("dados.txt", "r");
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    fclose(arquivo);

    return 0;
}//main