#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

    FILE* arquivo = fopen("dados.txt", "w");
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char frase[50] = "Agora eu escrevo no HD!!! =)";
    int tamanho = strlen(frase);
    for(int i=0; i<tamanho; i++){
        fputc(frase[i], arquivo);
    }//for

    fclose(arquivo);


    return 0;
}//main