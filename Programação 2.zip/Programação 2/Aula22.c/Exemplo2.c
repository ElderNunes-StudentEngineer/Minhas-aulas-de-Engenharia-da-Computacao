#include<stdio.h>
#include<stdlib.h>

int main(){

    FILE* arquivo = fopen("dados.txt", "w");
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char texto[30] = "Hello world em binário\n";
    float salario = 1302.45;
    int idade = 18;

    fprintf(arquivo, "%.2f", salario);
    fprintf(arquivo, "%s", texto);
    fprintf(arquivo, "%d", idade);

    fclose(arquivo);

    return 0;
}//main