#include<stdio.h>
#include<stdlib.h>

int main(){

    FILE* arquivo = fopen("dados.dat", "wb");//write binary
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char texto[30] = "Hello world em binário";
    float salario = 1302.45;
    int vetor[5] = {10,20,30,40,50};

    fwrite(&salario, sizeof(float), 1, arquivo);
    fwrite(texto, sizeof(char), 30, arquivo);
    fwrite(vetor, sizeof(int), 5, arquivo);

    fclose(arquivo);

    return 0;
}//main