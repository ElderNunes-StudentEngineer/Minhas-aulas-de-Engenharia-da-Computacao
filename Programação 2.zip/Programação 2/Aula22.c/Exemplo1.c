#include<stdio.h>
#include<stdlib.h>

int main(){

    FILE* arquivo = fopen("dados.dat", "rb");//read binary
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char texto[30]; 
    float salario;
    int vetor[5];

    fread(&salario, sizeof(float), 1, arquivo);
    fread(texto, sizeof(char), 30, arquivo);
    fread(vetor, sizeof(int), 5, arquivo);

    printf("Salário R$: %.2f\n", salario);
    printf("Texto: %s\n", texto);
    for(int i=0; i<5; i++){
        printf("Vetor(%d): %d\n", i, vetor[i]);
    }//for

    fclose(arquivo);

    return 0;
}//main