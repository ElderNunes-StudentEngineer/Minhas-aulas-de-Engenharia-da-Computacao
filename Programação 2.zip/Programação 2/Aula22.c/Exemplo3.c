#include<stdio.h>
#include<stdlib.h>

int main(){

    FILE* arquivo = fopen("dados.txt", "r");
    if(arquivo == NULL){
        perror("Erro ao abrir o arquivo");
        exit(1);
    }//if

    char texto[30];
    float salario;
    int idade;

    fscanf(arquivo, "%f", &salario);
    fscanf(arquivo, "%[^\n]\n", texto);
    fscanf(arquivo, "%d", &idade);

    printf("Texto: %s\n", texto);
    printf("Salário R$: %.2f\n", salario);
    printf("Idade: %d\n", idade);

    fclose(arquivo);

    return 0;
}//main