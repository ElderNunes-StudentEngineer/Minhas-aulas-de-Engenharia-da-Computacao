#include<stdio.h>
#include<stdlib.h>

/*
6) Considere a função X abaixo:

int X(int a){
  if(a <=0) return0;
  else return a + X(a-1);
}//X

O que essa função faz? Escreva uma função não-recursiva que resolve o mesmo problema.
*/

int main(){

    int a;
    printf("Digite o valor de A: ");
    scanf("%d", &a);

    if(a <= 0){
        return 0;
    }else{
        for(int i=a; i>0; i--){
            printf("%d\n", i);
        }
    }

    return 0;
}//main