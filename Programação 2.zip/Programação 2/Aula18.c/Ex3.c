#include<stdio.h>
#include<stdlib.h>

/*
3) Crie uma função que retorne x elevado a y através de operação de
multiplicação. A função recebe x e y por parâmetro
*/

int potenRecursiva(int x, int y){
    if(y == 0){
        return 1;
    }else{
        return x * potenRecursiva(x, y-1);
    }//else 
}//potenRecursiva

int main(){

    int x,y;

    printf("Digite o valor de x: ");
    scanf("%d", &x);

    printf("Digite o valor de y: ");
    scanf("%d", &y);

    int poten = potenRecursiva(x,y);

    printf("Potenciação: %d\n", poten);

    return 0;
}//main