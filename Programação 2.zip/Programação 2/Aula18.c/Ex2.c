#include<stdio.h>
#include<stdlib.h>

/*
2) Crie uma função que retorne x*y através de operação de soma. A função
recebe x e y por parâmetro
*/
// 5 * 4 = 5+5+5+5
// 5* 4 = 5+ (5*3)
// m(5,4) = 5+ m(5,3)
// m(x,y) = x + m(x, y-1)
int MultRecursiva(int x, int y){
    if(x == 0 || y == 0){
        return 0;
    }else{
        return x + MultRecursiva(x,y - 1);
    }//else
}//MultRecursiva

int main(){

    int x,y;

    printf("Digite o valor de x: ");
    scanf("%d", &x);

    printf("Digite o valor de y: ");
    scanf("%d", &y);

    int mult = MultRecursiva(x,y);

    printf("Multiplicação: %d\n", mult);

    return 0;
}//main