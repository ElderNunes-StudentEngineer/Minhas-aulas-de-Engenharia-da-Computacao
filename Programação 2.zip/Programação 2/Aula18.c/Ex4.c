#include <stdio.h>
#include<stdlib.h>

/*
Faça uma função recursiva que retorne o n-ésimo termo da sequência de Fibonacci, sendo que n é recebido por parâmetro. 
Utilize essa função para desenvolver um programa que mostre no main() os n termos dessa sequência na tela, a partir do valor de n recebido pelo teclado. 
Sabe-se que o 1º termo é 0 e o 2º termo é 1.
*/

int fibonacci(int n) {
    if (n <= 1) {
        return n;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }//else
}//fibonacci

int main() {
    int n;
    
    printf("Digite o valor de n para gerar os termos da sequência de Fibonacci: ");
    scanf("%d", &n);
    
    printf("Sequência de Fibonacci até o termo %d:\n", n);
    for (int i = 0; i < n; i++) {
        printf("%d ", fibonacci(i));
    }//for
    printf("\n");
    
    return 0;
}//main
