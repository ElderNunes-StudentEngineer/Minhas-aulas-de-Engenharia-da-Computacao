#include<stdio.h>
#include<stdlib.h>

/*
 1) Crie uma função que retorne o fatorial de um número passado por
parâmetro. A ideia do fatorial está abaixo:
*/

int fatRecursiva(int fatorial){
    if(fatorial == 1){
        return 1;
    }else if(fatorial > 0){
        return fatorial * fatRecursiva(fatorial - 1);
    }//else
}//fatRecurdiva

int main(){

    int fatorial;
    printf("Digite um número:");
    scanf("%d", &fatorial);

    int fat = fatRecursiva(fatorial);

    printf("Fatorial de %d é: %d\n", fatorial, fat);
    
}//main