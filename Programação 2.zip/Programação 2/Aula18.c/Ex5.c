#include <stdio.h>
#include<stdlib.h>

/*
5) Um problema típico em ciência da computação consiste em converter um número da sua forma decimal para binária. 
Crie um algoritmo recursivo para resolver esse problema.

●Solução trivial: x=0 quando o número inteiro já foi convertido para binário

●Passo da recursão: saber como x/2 é convertido. Depois, imprimir um dígito (0 ou 1) dado o sucesso da divisão.
*/

void decimalParaBinario(int n) {
    if (n == 0) {
        return;
    }//if
    
    decimalParaBinario(n / 2);
    
    printf("%d", n % 2);
}//decimalParaBinario

int main() {
    int decimal;
    
    printf("Digite o número decimal a ser convertido para binário: ");
    scanf("%d", &decimal);
    
    if (decimal < 0) {
        printf("O número decimal não pode ser negativo.\n");
        return 1;
    }//if

    printf("O número binário correspondente é: ");
    if (decimal == 0) {
        printf("0");
    } else {
        decimalParaBinario(decimal);
    }//else
    printf("\n");
    
    return 0;
}//main
