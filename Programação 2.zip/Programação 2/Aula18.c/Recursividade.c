#include<stdio.h>
#include<stdlib.h>

void exibeRecursiva(int numero){
    if(numero == 0){
        printf("Fim\n");
    }else{
        printf("Valor: %d\n", numero);
        exibeRecursiva(numero - 1);
        printf("Valor volta: %d\n", numero);
    }//else
}//exibeRecursiva

int main(){

    int numero = 5;
    exibeRecursiva(numero);

    return 0;
}//main