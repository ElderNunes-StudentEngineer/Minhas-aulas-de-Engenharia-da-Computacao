#include<stdio.h>
#include<stdlib.h>

int somaRecursiva(int numero){
    if(numero == 0){
        return 0;
    }else{
        return numero + somaRecursiva(numero - 1);
    }//else
}//somaRecursiva

int main(){

    int soma = somaRecursiva(5);
    printf("Soma: %d\n", soma);

    return 0;
}//main