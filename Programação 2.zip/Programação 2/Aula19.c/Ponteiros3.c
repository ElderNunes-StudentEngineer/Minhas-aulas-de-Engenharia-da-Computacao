#include<stdio.h>
#include<stdlib.h>

int main(){

    int vetor[5] = {10,20,30,40,50};

    for(int i=0; i<5; i++){
        printf("%d\n", *(vetor+i));
        //printf("%d\n", vetor[i]);
    }//for

    return 0;
}//main