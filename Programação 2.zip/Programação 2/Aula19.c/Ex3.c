#include<stdio.h>
#include<stdlib.h>
/*
3) Crie um programa que contenha uma matriz (3x3) de float. Imprima o endereço de cada posição dessa matriz.
*/
int main(){

    float matriz[3][3];
    float *ponteiro;

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            ponteiro = &matriz[i][j];
            printf("Endereço de memória da matriz(%d)(%d): %p\n", i+1, j+1, ponteiro);
        }//for
    }//for

    return 0;
}