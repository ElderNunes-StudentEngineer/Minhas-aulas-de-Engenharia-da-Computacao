#include<stdio.h>
#include<stdlib.h>
/*
1) Crie um programa que contenha um vetor float (tamanho 10). Imprima o endereço de cada posição desse vetor.
*/
int main(){

    float valor[10];
    
    for(int i=0; i<10; i++){
        printf("Endereço de mémoria %d: %p\n", i+1, *(valor+i));
    }//for

    return 0;
}//main