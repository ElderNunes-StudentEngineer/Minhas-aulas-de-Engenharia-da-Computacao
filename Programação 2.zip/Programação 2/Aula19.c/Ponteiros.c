#include<stdio.h>
#include<stdlib.h>

int main(){

    int idade = 18;
    int *ptrIdade = &idade;//pointer

    printf("Idade: %d\n", idade);
    printf("Idade: %d\n", *ptrIdade);
    printf("O ponteiro é: %p\n", ptrIdade);
    printf("O endereço do ponteiro: %p\n", &ptrIdade);

    return 0;
}//main 