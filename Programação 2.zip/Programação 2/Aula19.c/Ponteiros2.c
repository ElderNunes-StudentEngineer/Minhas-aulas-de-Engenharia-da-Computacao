#include<stdio.h>
#include<stdlib.h>

int main(){

    int valor1 = 10, valor2 = 10;
    int *ptr1, *ptr2;

    ptr1 = &valor1;
    ptr2 = &valor2;

    if(ptr1 == ptr2){
        printf("São Iguais!\n");
    }else{
        printf("São Diferentes!\n");
    }//else

    return 0;
}//main