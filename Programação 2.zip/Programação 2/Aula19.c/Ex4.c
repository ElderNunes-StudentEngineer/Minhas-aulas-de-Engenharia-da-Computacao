#include<stdio.h>
#include<stdlib.h>

/*
Crie um programa que contenha um vetor de inteiros de tamanho 5. 
Utilizando aritmética de ponteiros, leia os dados do teclado e exiba seus valores multiplicado por 2. 
Em seguida, exiba o endereço de memória das posições que contém valores pares.
*/

int main(){

    int vetor[5] = {10, 20, 30, 40, 50};
    int *ptrVetor;

    for(int i=0; i<5; i++){
        printf("Valores do vetor[%d]: %d\n", i+1, vetor[i]);
    }//for

    printf("\n");

    for(int i=0; i<5; i++){
        printf("Valores do vetor[%d] multiplicado por 2: %d\n", i+1, (vetor[i] * 2));
    }//for

    printf("\n");

    for(int i=0; i<5; i++){
        ptrVetor = &vetor[i];
        if(*ptrVetor % 2 == 0){
            printf("Endereço de memória do vetor[%d]: %p\n", i+1, ptrVetor);
        }//if
    }//for

    return 0;
}//main