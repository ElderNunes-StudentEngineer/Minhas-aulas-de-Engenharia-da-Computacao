#include<stdio.h>
#include<stdlib.h>

/*
1)Escreva um programa que contenha duas variáveis inteiras. Compare os endereços e exiba o endereço e o conteúdo do maior endereço.
*/

int main(){

    int n1 = 2;
    int n2 = 3;
    int *ptr1, *ptr2;

    ptr1 = &n1;
    ptr2 = &n2;

    if(ptr1 > ptr2){
        printf("O maior enderço de memória é: %p e seu conteúdo é: %d\n", ptr1, *ptr1);
    }else{
        printf("O maior enderço de memória é: %p e seu conteúdo é: %d\n", ptr2, *ptr2);
    }//else

    return 0;
}//main