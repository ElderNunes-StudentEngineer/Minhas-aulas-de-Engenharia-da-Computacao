#include<stdio.h>
#include<stdlib.h>

/*
1) Crie uma enumeração representando os meses do ano.
Agora, escreva um programa que leia um valor inteiro do
teclado e exiba o nome do mês correspondente e a
quantidade de dias que ele possui. 
*/

enum Meses {JANEIRO=1
, FEVEREIRO, MARÇO, ABRIL, MAIO, JUNHO, JULHO, AGOSTO, SETEMBRO, OUTUBRO, NOVEMBRO, DEZEMBRO};//enum

int main(){

    enum Meses hoje;
    int n;

    printf("Digite um valor inteiro correspondente ao mês:");
    scanf("%d", &n);
    if(n > 0 && n < 13){
        hoje = n;
    }else{
        exit(0);
    }//else

    if(hoje == JANEIRO){
        printf("JANEIRO\n");
    }else if(hoje == FEVEREIRO){
        printf("FEVEREIRO\n");
    }else if(hoje == MARÇO){
        printf("MARÇO\n");
    }else if(hoje == ABRIL){
        printf("ABRIL\n");
    }else if(hoje == MAIO){
        printf("MAIO\n");
    }else if(hoje == JUNHO){
        printf("JUNHO\n");
    }else if(hoje == JULHO){
        printf("JULHO\n");
    }else if(hoje == AGOSTO){
        printf("AGOSTO\n");
    }else if(hoje == SETEMBRO){
        printf("SETEMBRO\n");
    }else if(hoje == OUTUBRO){
        printf("OUTUBRO\n");
    }else if(hoje == NOVEMBRO){
        printf("NOVEMBRO\n");
    }else if(hoje == DEZEMBRO){
        printf("DEZEMBRO\n");

    }

    if(hoje == FEVEREIRO){
        printf("28 dias\n");
    }else if(hoje == JANEIRO || hoje == MARÇO || hoje == MAIO || hoje == JULHO || hoje == AGOSTO || hoje == OUTUBRO || hoje == DEZEMBRO){
        printf("31 dias\n");
    }else{
        printf("30 dias\n");
    }

    return 0;
}//main