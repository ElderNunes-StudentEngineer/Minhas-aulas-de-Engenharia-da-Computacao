#include<stdio.h>
#include<stdlib.h>
#include<locale.h>

/*
Crie um programa de cadastro que receba, armazene, e em seguida, exiba os dados de 5 pessoas.
Cada pessoa possui: nome, idade, peso, data de nascimento, brasileiro ou estrangeiro. Caso seja Brasileiro, armazene o CPF, caso estrangeiro, armazene o passaporte.

Regra: Utilize structs, typedef, union e enum.
*/

typedef enum { BRASILEIRO, ESTRANGEIRO } Nacionalidade;

typedef union {
    char cpf[12];
    char passaporte[12];
} Documento;

typedef struct {
    char nome[21];
    int idade;
    float peso;
    int dia_nascimento;
    int mes_nascimento;
    int ano_nascimento;
    Nacionalidade nacionalidade;
    Documento documento;
} Cadastro;

int main() {
    setlocale(LC_ALL, "");

    int i;
    Cadastro pessoas[5];
    for(i = 0; i < 5; i++) {
        printf("Digite seu nome:\n");
        scanf(" %20[^\n]", pessoas[i].nome);
        setbuf(stdin, NULL);
        printf("Digite sua idade:\n");
        scanf("%d", &pessoas[i].idade);
        printf("Digite seu peso:\n");
        scanf("%f", &pessoas[i].peso);
        printf("Digite sua Data de Nascimento (DD/MM/AAAA):\n");
        scanf("%d/%d/%d", &pessoas[i].dia_nascimento, &pessoas[i].mes_nascimento, &pessoas[i].ano_nascimento);
        printf("Digite sua nacionalidade (0 para Brasileiro, 1 para Estrangeiro):\n");
        scanf("%d", &pessoas[i].nacionalidade);
        if (pessoas[i].nacionalidade == BRASILEIRO) {
            printf("Digite seu CPF:\n");
            scanf("%11s", pessoas[i].documento.cpf);
        } else if (pessoas[i].nacionalidade == ESTRANGEIRO) {
            printf("Digite seu Passaporte:\n");
            scanf("%11s", pessoas[i].documento.passaporte);
        }
    }

    for(i = 0; i < 5; i++) {
        printf("\nDados da Pessoa %d:\n", i+1);
        printf("Nome: %s\n", pessoas[i].nome);
        printf("Idade: %d\n", pessoas[i].idade);
        printf("Peso: %.2f\n", pessoas[i].peso);
        printf("Data de Nascimento: %02d/%02d/%04d\n", pessoas[i].dia_nascimento, pessoas[i].mes_nascimento, pessoas[i].ano_nascimento);
        if (pessoas[i].nacionalidade == BRASILEIRO) {
            printf("Nacionalidade: Brasileiro\n");
            printf("CPF: %s\n", pessoas[i].documento.cpf);
        } else if (pessoas[i].nacionalidade == ESTRANGEIRO) {
            printf("Nacionalidade: Estrangeiro\n");
            printf("Passaporte: %s\n", pessoas[i].documento.passaporte);
        }
    }

    return 0;
}