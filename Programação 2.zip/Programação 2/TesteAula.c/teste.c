#include<stdio.h>
#include<stdlib.h>

int main(){

    printf("Hello GITHUB!\n");
    return 0;
}