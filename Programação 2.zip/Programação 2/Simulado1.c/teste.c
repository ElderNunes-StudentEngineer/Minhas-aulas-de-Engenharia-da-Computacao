#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Você foi contratado pela Riot Games para elaborar partes do sistema sistema de Ranking do League of Legends. Para isso:

a) Defina um tipo e estrutura para salvar os dados de jogadores para um Ranking.
Cada jogador possui: nome, vitórias, derrotas, tier(nível) e pontos.

Os tiers são: Bronze, Prata, Ouro, Platina, Diamante e Desafiante. Para organizar os níveis utilize uma enumeração.

b) Receba do teclado e armazene os dados de 6 jogadores. Não devem ser permitidos valores negativos, novos valores devem ser solicitados caso necessário.

c) Exiba uma tabela alinhada com o nome e a taxa de vitórias (winrate) de cada jogador
  winrate = vitórias / (vitórias+derrotas) * 100.
  Cada calculo deve ser feito por meio de uma função adicional que recebe o número de vitórias e derrotas via cópia e retorna o winrate.

d) Exiba uma tabela com os líderes (maior número de pontos) de cada um dos níveis. Para isso, faça uma função extra que receba um tier e retorne uma estrutura do tipo Jogador com os dados do líder.

e) Faça a busca de um jogador pelo nome digitado. A busca deve ser feita por uma função adicional que recebe o nome e retorna os dados de vitórias, derrotas, tier e pontos via referência.

f) Utilizando uma função recursiva, calcule a soma de todas as partidas (vitórias e derrotas) de todos os jogadores.

Cada um dos itens de B a E deve ser implementada em uma função diferente.
Não é permitido o uso de variáveis globais.
Nas funções extras, caso necessário, utilize parâmetros adicionais.
*/

typedef enum{
    BRONZE = 1,
    PRATA,
    PLATINA, 
    OURO,
    DIAMANTE, 
    DESAFIANTE,
}Tier;

typedef struct{
    char nome[30];
    int vitorias;
    int derrotas;
    Tier tier;
    float pontos;
}Cadastro;

int DadosJogadores(Cadastro jogador[]){
    for(int i=0; i<6; i++){
    printf("Digite o nome do jogador %d: ", i+1);
    scanf("%29[^\n]", jogador[i].nome);
    setbuf(stdin, NULL);

    do{
        printf("Digite o número de vitórias do jogador %d: ",i+1);
        scanf("%d", &jogador[i].vitorias);
    }while(jogador[i].vitorias < 0);

    do{
        printf("Digite o número de derrotas do jogador %d: ", i+1);
        scanf("%d", &jogador[i].derrotas);
    }while(jogador[i].derrotas < 0);

    do{
        int nivel;
        printf("Digite o tier do jogador %d: ", i+1);
        scanf("%d", &nivel);
        jogador[i].tier = (Tier)(nivel - 1); 
    }while(jogador[i].tier < 1 || jogador[i].tier > 6);

    do{
        printf("Digite o número de pontos do jogador %d: ", i+1);
        scanf("%f", &jogador[i].pontos);
    }while(jogador[i].pontos);
    setbuf(stdin, NULL);
    }//for
    return 0;
}//DadosJogadores

int main(){
    //Letra A
    Cadastro jogador[6];
    //Letra B
    DadosJogadores(jogador);

    return 0;
}//main