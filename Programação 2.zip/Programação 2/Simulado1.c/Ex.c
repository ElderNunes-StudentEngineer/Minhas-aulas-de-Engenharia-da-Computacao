#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*
Você foi contratado pela Riot Games para elaborar partes do sistema sistema de Ranking do League of Legends. Para isso:

a) Defina um tipo e estrutura para salvar os dados de jogadores para um Ranking.
Cada jogador possui: nome, vitórias, derrotas, tier(nível) e pontos.

Os tiers são: Bronze, Prata, Ouro, Platina, Diamante e Desafiante. Para organizar os níveis utilize uma enumeração.

b) Receba do teclado e armazene os dados de 6 jogadores. Não devem ser permitidos valores negativos, novos valores devem ser solicitados caso necessário.

c) Exiba uma tabela alinhada com o nome e a taxa de vitórias (winrate) de cada jogador
  winrate = vitórias / (vitórias+derrotas) * 100.
  Cada calculo deve ser feito por meio de uma função adicional que recebe o número de vitórias e derrotas via cópia e retorna o winrate.

d) Exiba uma tabela com os líderes (maior número de pontos) de cada um dos níveis. Para isso, faça uma função extra que receba um tier e retorne uma estrutura do tipo Jogador com os dados do líder.

e) Faça a busca de um jogador pelo nome digitado. A busca deve ser feita por uma função adicional que recebe o nome e retorna os dados de vitórias, derrotas, tier e pontos via referência.

f) Utilizando uma função recursiva, calcule a soma de todas as partidas (vitórias e derrotas) de todos os jogadores.

Cada um dos itens de B a E deve ser implementada em uma função diferente.
Não é permitido o uso de variáveis globais.
Nas funções extras, caso necessário, utilize parâmetros adicionais.

Texto de resposta Questão 1
*/
 int i;
 
 typedef enum{
 	BRONZE = 1,
    PRATA,
    OURO,
    PLATINA,
    DIAMANTE,
    DESAFIANTE
 }Tier;
 
typedef struct{
    char nome[50];
    int vitorias;
    int derrotas;
    Tier tier;
    float pontos;
}StructLOL;
 
int Cadastro(StructLOL dados[]){
        for( i=0; i<6; i++){
        printf("Digite o nome %d: ", i+1);
        scanf("%49[^\n]", dados[i].nome);
do{
        printf("Digite o número de vitórias do jogador %d: ", i+1);
        scanf("%d", &dados[i].vitorias);
}while(dados[i].vitorias < 0);

do{    
        printf("Digite o número de derrotas do jogador %d: ", i+1);
        scanf("%d", &dados[i].derrotas);
}while (dados[i].derrotas < 0);

do{
    printf(" 1-Bronze\n 2-Prata\n 3-Ouro\n 4-Platina\n 5-Diamante\n 6-Desafiante\n");
        printf("Digite o tier(nível) do jogador %d: ", i+1);
        int tier;
        scanf("%d", &tier);
        dados[i].tier = (Tier)(tier - 1);
}while (dados[i].tier < 0);
        
do{        
        printf("Digite o número de pontos do jogador %d: ", i+1);
        scanf("%f", &dados[i].pontos);
}while(dados[i].pontos < 0);        
        setbuf(stdin, NULL);
    }//for

}//Cadastro

float CalcularWinrate(int vitorias, int derrotas){
    return (float) vitorias / (vitorias + derrotas) * 100; 
}//CalcularWinrate

void TabelaWinrate(StructLOL dados[]){
	printf("TABELA\n");
    for(i=0; i<6; i++){
    	float winrate = CalcularWinrate(dados[i].vitorias, dados[i].derrotas);
        printf("Nome do jogador %d: %-20s | Winrate: %-10.2f%\n", i+1, dados[i].nome, winrate);
    }//for
}//TabelaWinrate

StructLOL EncontrarLideres(StructLOL dados[], Tier tier){
	StructLOL lider = {" ", 0, 0, BRONZE, -1};
	for(i=0; i<6; i++){
		if(dados[i].tier == tier && dados[i].pontos > lider.pontos){
			lider = dados[i];		
		}//if
	}//for
	return lider;
}//EncontrarLideres

void ImprimeJogador(StructLOL dados[]){
	printf("Líderes de cada tier:\n");
    for(i=BRONZE; i<=DESAFIANTE; i++){
    	StructLOL lider = EncontrarLideres(dados, (Tier)i);	
    	printf("Tier %d: %s com %.2f pontos.\n", i, lider.nome, lider.pontos);
	}//for
}//ImprimeJogador

int NomeBuscado(StructLOL dados[], char buscaNome[], StructLOL* jogador){
	for(i=0; i<6; i++){
		if(!strcmp(dados[i].nome, buscaNome)){
			*jogador = dados[i];	
		}//if
	}//for
}//NomeBuscado

void DadosJogador(StructLOL jogador){
	printf("O jogador: %s, possui %d vitórias, %d derrotas, seu tier é: %d e tem %.2f pontos.", jogador.nome, jogador.vitorias, jogador.derrotas, jogador.tier, jogador.pontos);	
}//DadosJogador

//f) Utilizando uma função recursiva, calcule a soma de todas as partidas (vitórias e derrotas) de todos os jogadores.

int SomaPartidas(StructLOL dados[], int n){
	for(i=0; i<6; i++){
		if(n == 0){
			return dados[0].vitorias + dados[0].derrotas;
		}else{
			return dados[n].vitorias + dados[n].derrotas + SomaPartidas(dados, n-1);
		}//else
	}//for
}//SomaPartidas

int main(){
	//Letra A
    StructLOL dados[6];
	//Letra B
    Cadastro(dados);
    //Letra C
    TabelaWinrate(dados);
    //Letra D
	ImprimeJogador(dados);
	
	StructLOL jogador;
	
	//Letra E
	char buscaNome[50];
	printf("Digite o nome a ser buscado: ");
	scanf("%49[^\n]", buscaNome);
	NomeBuscado(dados, buscaNome, &jogador);
	DadosJogador(jogador);
	//Letra F);
	printf("\n Foram disputadas %d partidas pelos %d jogadores.\n",SomaPartidas(dados, i),i);

    return 0;
}//main