#include <gtk/gtk.h>

// Função chamada quando o botão é clicado
void button_clicked(GtkWidget *widget, gpointer data) {
    g_print("Botão clicado!\n");
    gtk_main_quit(); // Fecha o loop principal do GTK
}

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *button;

    // Inicializa o GTK
    gtk_init(&argc, &argv);

    // Cria uma nova janela
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Exemplo GTK em C");
    gtk_container_set_border_width(GTK_CONTAINER(window), 10);
    gtk_widget_set_size_request(window, 200, 100);

    // Cria um botão
    button = gtk_button_new_with_label("Clique-me");

    // Conecta o sinal 'clicked' do botão à função 'button_clicked'
    g_signal_connect(button, "clicked", G_CALLBACK(button_clicked), NULL);

    // Adiciona o botão à janela
    gtk_container_add(GTK_CONTAINER(window), button);

    // Exibe todos os widgets
    gtk_widget_show_all(window);

    // Inicia o loop principal do GTK
    gtk_main();

    return 0;
}
