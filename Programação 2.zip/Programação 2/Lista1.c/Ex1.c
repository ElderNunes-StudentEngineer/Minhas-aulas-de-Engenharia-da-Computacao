#include<stdio.h>
#include<stdlib.h>

/*
1) Crie uma estrutura representando um atleta. 
Essa estrutura deve conter o nome do atleta, seu esporte, idade e altura. 
Agora, escreva um programa que leia os dados de cinco atletas. 
Calcule e exiba os nomes do atleta mais alto e do mais velho.
*/

typedef struct{
    char nome[21];
    char nomeEsporte[51];
    int idade;
    float altura;
}Atleta;//struct

int main(){

    Atleta atleta[5];

    for(int i=0; i<5; i++){
    printf("Digite o nome do atleta: ");
    scanf("%20[^\n]", atleta[i].nome);
    setbuf(stdin, NULL);

    printf("Digite o nome do esporte praticado: ");
    scanf("%50[^\n]", atleta[i].nomeEsporte);

    printf("Digite sua idade: ");
    scanf("%d", &atleta[i].idade);

    printf("Digite sua altura: ");
    scanf("%f", &atleta[i].altura);
    setbuf(stdin, NULL);
    printf("\n");
    }//for

    float maiorAltura = 0;
    int posMaior = 0;
    for(int i=0; i<5; i++){
        if(atleta[i].altura > maiorAltura){
            maiorAltura = atleta[i].altura;
            posMaior = i;
        }//if
    }//for

    int maiorIdade = 0;
    int posIdade = 0;
    for(int i=0; i<5; i++){
        if(atleta[i].idade > maiorIdade){
            maiorIdade = atleta[i].idade;
            posIdade = i;
        }//if
    }//for

    printf("A nome do maior atleta é: %s\n", atleta[posMaior].nome);
    printf("A nome do atleta mais velho é: %s\n", atleta[posIdade].nome);





    return 0;
}//main