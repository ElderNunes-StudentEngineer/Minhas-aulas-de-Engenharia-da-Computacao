#include<stdio.h>
#include<stdlib.h>

/*
2) Usando a estrutura “atleta” do exercício anterior, escreva um programa que leia os dados de cinco atletas e os exiba por ordem de idade, 
do mais velho para o mais novo.
Dica: Procure pelo algoritmo BubbleSort no Google
*/


typedef struct{
    char nome[21];
    char nomeEsporte[51];
    int idade;
    float altura;
}Atleta;//struct

int main(){

    Atleta atleta[5];

    for(int i=0; i<5; i++){
    printf("Digite o nome do atleta: ");
    scanf("%20[^\n]", atleta[i].nome);
    setbuf(stdin, NULL);

    printf("Digite o nome do esporte praticado: ");
    scanf("%50[^\n]", atleta[i].nomeEsporte);

    printf("Digite sua idade: ");
    scanf("%d", &atleta[i].idade);

    printf("Digite sua altura: ");
    scanf("%f", &atleta[i].altura);
    setbuf(stdin, NULL);
    printf("\n");
    }//for

    int aux = 0;
    char atletas[21];

    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
            if(atleta[i].idade > atleta[j].idade){
                aux = atleta[i].idade;
                strcpy(atletas, atleta[i].nome);

                atleta[i].idade = atleta[j].idade;
                strcpy(atleta[i].nome, atleta[j].nome);  

                strcpy(atleta[j].nome, atletas);
                
                atleta[j].idade = aux;
            }//if
        }//for
    }//for

    printf("Atletas do mais velho para o mais novo:\n");
    for(int i=0; i<5; i++){
    printf("Nome:| %20s |Idade:| %20d |\n", atleta[i].nome, atleta[i].idade);
    }//for

    return;
}//main