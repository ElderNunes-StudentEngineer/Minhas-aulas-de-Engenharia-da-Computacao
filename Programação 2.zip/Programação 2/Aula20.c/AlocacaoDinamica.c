#include<stdio.h>
#include<stdlib.h>

int main(){

//  int vetor[10];

    int* vetorDinamico =(int*) malloc(10 * sizeof(int)); 

    if(vetorDinamico == NULL){
        printf("Erro ao alocar memória!");
        exit(EXIT_FAILURE);
        //exit(1), para fora da main
    }//if

    for(int i=0; i<10; i++){
        printf("Digite o vetor[%d]: ", i);
        scanf("%d", &vetorDinamico[i]);
    }//for
    printf("\n");
    for(int i=0; i<10; i++){
        printf("Exibindo o vetor[%d]: %d\n", i, vetorDinamico[i]);
    }//for

    free(vetorDinamico);
    return 0;
}//main