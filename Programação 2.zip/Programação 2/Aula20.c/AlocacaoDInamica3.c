#include<stdio.h>
#include<stdlib.h>

int main(){

    int linhas = 5;
    int colunas = 3;

    int** matriz = (int**) malloc(linhas * sizeof(int*));
    for(int i=0; i<linhas; i++){
        matriz[i] = (int*) malloc(colunas * sizeof(int));
    }//for

    for(int l=0; l<linhas; l++){
        for(int c=0; c<colunas; c++){
            printf("Digite o valor da matriz(%d)(%d): ", l,c);
            scanf("%d", &matriz[l][c]);
        }//for
    }//for
    printf("\n");
    for(int l=0; l<linhas; l++){
        for(int c=0; c<colunas; c++){
            printf("matriz(%d)(%d): %d\n", l,c, matriz[l][c]);
        }//for
    }//for

    for(int i=0; i<linhas; i++){
        free(matriz[i]);
    }//for

    free(matriz);

    return EXIT_FAILURE;
}//main