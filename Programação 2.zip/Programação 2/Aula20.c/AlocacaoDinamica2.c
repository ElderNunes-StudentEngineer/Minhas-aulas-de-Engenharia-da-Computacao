#include<stdio.h>
#include<stdlib.h>

int main(){

    int tamanho;
    printf("Digite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    int *vetorDinamico = (int*) calloc(tamanho, sizeof(int));

    if(vetorDinamico == NULL){
        printf("Erro ao alocar memória!\n");
        exit(1);
        //exit(1), para fora da main
    }//if

    for(int i=0; i<tamanho; i++){
        printf("Digite o vetor[%d]: ", i);
        scanf("%d", &vetorDinamico[i]);
    }//for
    printf("\n");
    for(int i=0; i<tamanho; i++){
        printf("Exibindo o vetor[%d]: %d\n", i, vetorDinamico[i]);
    }//for

    printf("\nDigite o novo tamanho do vetor: ");
    scanf("%d", &tamanho);

    vetorDinamico = (int*) realloc(vetorDinamico, tamanho);

    if(vetorDinamico == NULL){
        printf("Erro ao alocar memória!\n");
        exit(1);
        //exit(1), para fora da main
    }//if

    for(int i=0; i<tamanho; i++){
        printf("Digite o vetor[%d]: ", i);
        scanf("%d", &vetorDinamico[i]);
    }//for
    printf("\n");
    for(int i=0; i<tamanho; i++){
        printf("Exibindo o vetor[%d]: %d\n", i, vetorDinamico[i]);
    }//for

    free(vetorDinamico);
    return EXIT_FAILURE;
}