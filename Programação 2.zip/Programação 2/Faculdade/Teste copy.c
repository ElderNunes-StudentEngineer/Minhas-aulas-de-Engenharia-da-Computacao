#include<stdio.h>
#include<stdlib.h>

int main(){

    printf("Hello Git World!!\n");
    return 0;
}