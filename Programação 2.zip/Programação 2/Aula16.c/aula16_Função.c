#include<stdio.h>
#include<stdlib.h>
/*
int recebeIdade(){
    int idade;
    printf("Digite sua idade:");
    scanf("%d", &idade);
    return idade;
}

void exibeIdade(int idade){
    printf("Você tem %d anos\n", idade);
    return;
}//exibeIdade

int main(){
    int IdadeRecebida;
    IdadeRecebida = recebeIdade();
    exibeIdade(IdadeRecebida);
    return 0;
}//main

int calculaQuadrado(int numero){
    int quadrado;
    quadrado = numero * numero;
    return quadrado;
}//calculaQuadrado

int main(){
    int meuQuadrado;
    int numero;
    printf("Digite um número:");
    scanf("%d", &numero);
    meuQuadrado = calculaQuadrado(numero);

    printf("O quadrado é: %d\n", meuQuadrado);

    return 0;
}//main
*/

int main(int argc, char **argv){

    printf("Quantidade de argumentos: %d\n", argc);

    for(int i=0; i<argc; i++){
        printf("O argumento %d é: %s\n", i, argv[i]);
    }

    return 0;
}//main