#include<stdio.h>
#include<stdlib.h>

/*
1) Crie uma função que receba uma string e retorne um ponteiro para uma outra string que foi alocada dinâmicamente contendo 
a mesma string mas agora com o conteúdo invertido.
*/

int main(){

    char str1[21];
    printf("Digite a string: ");
    scanf("%[^\n]", str1);

    char* stringDinamica = (char*) malloc()


    return 0;
}//main